from django.shortcuts import render, redirect,  get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages

from .forms import *
from .models import *
from django.db.models import Q

from django.http import JsonResponse
from django.conf import settings
import os

import joblib
import numpy as np

def base(request):
    return render(request, 'base.html')

def about(request):
    return render(request, 'about/about.html')

def register(request):
    if request.method == 'POST':
        user_form = UserRegistrationForm(request.POST)
        if user_form.is_valid():
            #create a new registration object and avoid saving it yet
            new_user = user_form.save(commit=False)
            #reset the choosen password
            new_user.set_password(user_form.cleaned_data['password'])
            #save the new registration
            new_user.save()
            return render(request, 'registration/register_done.html',{'new_user':new_user})
    else:
        user_form = UserRegistrationForm()
    return render(request, 'registration/register.html',{'user_form':user_form})

def profile(request):
    return render(request, 'profile/profile.html')



@login_required
def edit_profile(request):
    if request.method == 'POST':
        user_form = EditProfileForm(request.POST, request.FILES, instance=request.user)
        if user_form.is_valid():
            user = user_form.save()
            profile = user.profile
            if 'profile_picture' in request.FILES:
                profile.profile_picture = request.FILES['profile_picture']
            profile.save()
            messages.success(request, 'Your profile was successfully updated!')
            return redirect('profile')
    else:
        user_form = EditProfileForm(instance=request.user)
    
    return render(request, 'profile/edit_profile.html', {'user_form': user_form})

@login_required
def delete_account(request):
    if request.method == 'POST':
        request.user.delete()
        messages.success(request, 'Your account was successfully deleted.')
        return redirect('base')  # Redirect to the homepage or another page after deletion

    return render(request, 'registration/delete_account.html')
# das
@login_required
def dashboard(request):
    users_count = User.objects.all().count()
    consumers = Consumer.objects.all().count

    context = {
        'users_count':users_count,
        'consumers':consumers,
    }
    return render(request, "dashboard/dashboard.html", context=context)
#CRUD operations start here
@login_required
def dashvalues(request):
    consumers = Consumer.objects.all()
    search_query = ""
    
    if request.method == "POST": 
        if "create" in request.POST:
            name = request.POST.get("name")
            email = request.POST.get("email")
            image = request.FILES.get("image")
            content = request.POST.get("content")

            Consumer.objects.create(
                name=name,
                email=email,
                image=image,
                content=content
            )
            messages.success(request, "Consumer added successfully")
    
        elif "update" in request.POST:
            id = request.POST.get("id")
            name = request.POST.get("name")
            email = request.POST.get("email")
            image = request.FILES.get("image")
            content = request.POST.get("content")

            consumer = get_object_or_404(Consumer, id=id)
            consumer.name = name
            consumer.email = email
            consumer.image = image
            consumer.content = content
            consumer.save()
            messages.success(request, "Consumer updated successfully")
    
        elif "delete" in request.POST:
            id = request.POST.get("id")
            Consumer.objects.get(id=id).delete()
            messages.success(request, "Consumer deleted successfully")
        
        elif "search" in request.POST:
            search_query = request.POST.get("query")
            consumers = Consumer.objects.filter(Q(name__icontains=search_query) | Q(email__icontains=search_query))

    context = {
        "consumers": consumers, 
        "search_query": search_query
    }
    return render(request, "crud/dashvalue.html", context=context)
# CRUD operations end here

# Contact start
@login_required
def contact(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Thank you for contacting us!")
            return redirect('dashboard')  # Redirect to the same page to show the modal
    else:
        form = ContactForm()

    return render(request, 'contact/contact_form.html', {'form': form})

# contact end
import numpy as np
import matplotlib.pyplot as plt
import io
import urllib, base64
from django.shortcuts import render
from .forms import UserInputForm
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import joblib
import os

# Define the path to the models
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_PATH = os.path.join(BASE_DIR, 'myapp', 'models')

# Load models and preprocessing tools
models = {
    'Logistic Regression': joblib.load(os.path.join(MODEL_PATH, 'logistic_regression.pkl')),
    'Decision Tree': joblib.load(os.path.join(MODEL_PATH, 'decision_tree.pkl')),
    'Random Forest': joblib.load(os.path.join(MODEL_PATH, 'random_forest.pkl')),
    'Support Vector Machine': joblib.load(os.path.join(MODEL_PATH, 'support_vector_machine.pkl')),
    'XGBoost': joblib.load(os.path.join(MODEL_PATH, 'xgboost.pkl'))
}
scaler = joblib.load(os.path.join(MODEL_PATH, 'scaler.pkl'))
pca = joblib.load(os.path.join(MODEL_PATH, 'pca.pkl'))

def predict(request):
    # Default values as a dictionary
    default_values = {
        'age': 69,
        'sex': 1,
        'cp': 0,
        'trestbps': 160,
        'chol': 234,
        'fbs': 1,
        'restecg': 2,
        'thalach': 131,
        'exang': 0,
        'oldpeak': 0.1,
        'slope': 1,
        'ca': 1,
        'thal': 0
    }

    if request.method == 'POST':
        form = UserInputForm(request.POST)
        if form.is_valid():
            user_input = [
                form.cleaned_data['age'],
                form.cleaned_data['sex'],
                form.cleaned_data['cp'],
                form.cleaned_data['trestbps'],
                form.cleaned_data['chol'],
                form.cleaned_data['fbs'],
                form.cleaned_data['restecg'],
                form.cleaned_data['thalach'],
                form.cleaned_data['exang'],
                form.cleaned_data['oldpeak'],
                form.cleaned_data['slope'],
                form.cleaned_data['ca'],
                form.cleaned_data['thal'],
            ]
            user_input = np.array(user_input).reshape(1, -1)
            scaled_user_input = scaler.transform(user_input)
            pca_user_input = pca.transform(scaled_user_input)

            predictions = {}
            cardiac_disease_predictions = []
            for name, model in models.items():
                prob = model.predict_proba(pca_user_input)[:, 1][0]
                predictions[name] = prob
                if prob > 0.5:
                    cardiac_disease_predictions.append(name)

            # Determine if the user is suffering from cardiac disease based on majority vote
            has_cardiac_disease = "Yes" if len(cardiac_disease_predictions) > 0 else "No"

            # Generate bar plot
            plt.figure(figsize=(10, 6))
            plt.bar(predictions.keys(), predictions.values())
            plt.ylabel('Probability of Heart Disease')
            plt.title('Model Predictions Comparison')
            plt.ylim(0, 1)

            buf = io.BytesIO()
            plt.savefig(buf, format='png')
            buf.seek(0)
            string = base64.b64encode(buf.read())
            uri = 'data:image/png;base64,' + urllib.parse.quote(string)

            return render(request, 'predictor/results.html', {
                    'form': form, 
                    'uri': uri, 
                    'has_cardiac_disease': has_cardiac_disease,
                    'cardiac_disease_predictions': cardiac_disease_predictions
                })

    else:
        form = UserInputForm(initial=default_values)  # Set default values

    return render(request, 'predictor/predict.html', {'form': form})

import csv
import os
from django.shortcuts import render
from django.conf import settings
from django.core.paginator import Paginator
from django.http import HttpResponse

def dataset(request):
    data = []
    headers = []
    dataset_path = os.path.join(settings.BASE_DIR, 'myapp\dataset\heart_cleveland_upload.csv')
    
    if not os.path.exists(dataset_path):
        return HttpResponse("CSV file not found.", status=404)
    
    with open(dataset_path, newline='') as csvfile:
        reader = csv.reader(csvfile)
        try:
            headers = next(reader)  # Get the headers (first row)
        except StopIteration:
            headers = []
        
        for row in reader:
            data.append(row)
    
    # Paginate the data
    paginator = Paginator(data, 10)  # Show 10 rows per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'headers': headers,
        'page_obj': page_obj
    }
    return render(request, 'dataset/dataset.html', context)
